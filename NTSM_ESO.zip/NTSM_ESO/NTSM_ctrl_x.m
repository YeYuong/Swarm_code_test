function [sys,x0,str,ts]=NTSM_ctrl_x(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 5;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[];
function sys=mdlOutputs(t,x,u)
x=u(1);
dx=u(2);
ddx=u(3);
xd=u(4);
d=u(5);
% d=0;

% dxd=0;
% ddxd=0;

dxd=0.1*cos(0.1*t);
ddxd=-0.01*sin(0.1*t);


e=x-xd;
de=dx-dxd;
dde=ddx-ddxd;

m=1.5;


b=0.2;
xite=0.02;
k=0.2;
q=3;p=5;

if de<0
    s=e+1/b*-(abs(de^(p/q)));
    ut=(ddxd-k*s-(xite+0*d)*sign(s)-b*q/p*-(abs(de^(2-p/q))))*m-d;
else
    s=e+1/b*de^(p/q);
    ut=(ddxd-k*s-(xite+0*d)*sign(s)-b*q/p*de^(2-p/q))*m-d;
end

% if de<0   
%     s=e+a*e^r+b*-(abs(de^(p/q)));
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*-(abs(de^(p/q))))*m;
% else
%     s=e+a*e^r+b*de^(p/q);
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*de^(2-p/q))*m;
% end

sys(1)=ut;
sys(2)=e;
sys(3)=de;
sys(4)=s;
function [sys,x0,str,ts]=NTSM_ctrl_Tz(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 7;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[];
function sys=mdlOutputs(t,x,u)
psi=u(1);
dpsi=u(2);
ddpsi=u(3);
psid=u(4);
dpsid=0;
ddpsid=0;
dphi=u(5);
dtheta=u(6);
d=u(7);


e=psi-psid;
de=dpsi-dpsid;
dde=ddpsi-ddpsid;

b=6;        %6
xite=0.8;   %0.8 
k=3;        %3
q=3;p=5;

Ixx=1.745e-2;%x轴转动惯量
Iyy=1.745e-2;%y轴转动惯量
Izz=3.175e-2;%z轴转动惯量

fai=0.02;

if de<0
    s=e+1/b*-(abs(de^(p/q)));
%     if abs(s)<=fai
%         sat=s/fai;
%     else
%         sat=sign(s);
%     end
    ut=(ddpsid-k*s-(xite)*sign(s)-b*q/p*-(abs(de^(2-p/q)))-dphi*dtheta*((Ixx-Iyy)/Izz))*Izz-0.8*d;
else
    s=e+1/b*de^(p/q);
%     if abs(s)<=fai
%         sat=s/fai;
%     else
%         sat=sign(s);
%     end
    ut=(ddpsid-k*s-(xite)*sign(s)-b*q/p*de^(2-p/q)-dphi*dtheta*((Ixx-Iyy)/Izz))*Izz-0.8*d;
end

% if de<0   
%     s=e+a*e^r+b*-(abs(de^(p/q)));
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*-(abs(de^(2-p/q))))*m;
% else
%     s=e+a*e^r+b*de^(p/q);
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*de^(2-p/q))*m;
% end

sys(1)=ut;
sys(2)=e;
sys(3)=de;
sys(4)=s;
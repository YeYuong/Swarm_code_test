function [sys,x0,str,ts]=NTSM_ctrl_Ty(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 9;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[];
function sys=mdlOutputs(t,x,u)
theta=u(1);
dtheta=u(2);
ddtheta=u(3);
thetad=u(4);
dthetad=u(5);
ddthetad=u(6);
dphi=u(7);
dpsi=u(8);
d=u(9);



e=theta-thetad;
de=dtheta-dthetad;
dde=ddtheta-ddthetad;


b=0.5;
xite=0.8;
k=1;
q=3;p=5;

Ixx=1.745e-2;%x轴转动惯量
Iyy=1.745e-2;%y轴转动惯量
Izz=3.175e-2;%z轴转动惯量

% fai=0.02;

if de<0
    s=e+1/b*-(abs(de^(p/q)));
%     if abs(s)<=fai
%         sat=s/fai;
%     else
%         sat=sign(s);
%     end
    ut=(ddthetad-xite*sign(s)-b*q/p*-(abs(de^(2-p/q)))-dphi*dpsi*((Izz-Ixx)/Iyy))*Iyy-0.2*d;
else 
    s=e+1/b*de^(p/q);
%     if abs(s)<=fai
%         sat=s/fai;
%     else
%         sat=sign(s);
%     end
    ut=(ddthetad-xite*sign(s)-b*q/p*de^(2-p/q)-dphi*dpsi*((Izz-Ixx)/Iyy))*Iyy-0.2*d;
end

% if de<0   
%     s=e+a*e^r+b*-(abs(de^(p/q)));
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*-(abs(de^(p/q))))*m;
% else
%     s=e+a*e^r+b*de^(p/q);
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*de^(2-p/q))*m;
% end

sys(1)=ut;
sys(2)=e;
sys(3)=de;
sys(4)=s;
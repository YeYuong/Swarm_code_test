function [sys,x0,str,ts]=NTSM_ctrl_y(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 5;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[];
function sys=mdlOutputs(t,x,u)
y=u(1);
dy=u(2);
ddy=u(3);
yd=u(4);
d=u(5);
% d=0;

% dyd=0;
% ddyd=0;

dyd=-0.1*sin(0.1*t);
ddyd=-0.01*cos(0.1*t);



e=y-yd;
de=dy-dyd;
dde=ddy-ddyd;

m=1.5;
g=9.81;


b=0.02;
xite=0.02;
k=0.1;
q=3;p=5;


fai=0.02;


if de<0
    s=e+1/b*-(abs(de^(p/q)));
%     if abs(s)<=fai
%     sat=s/fai;
%     else
%     sat=sign(s);
%     end
    ut=(ddyd-k*s-(xite+0*d)*sign(s)-b*q/p*-(abs(de^(2-p/q))))*m-d;
else
    s=e+1/b*de^(p/q);
%     if abs(s)<=fai
%         sat=s/fai;
%     else
%         sat=sign(s);
%     end
    ut=(ddyd-k*s-(xite+0*d)*sign(s)-b*q/p*de^(2-p/q))*m-d;
end

% if de<0   
%     s=e+a*e^r+b*-(abs(de^(p/q)));
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*-(abs(de^(p/q))))*m;
% else
%     s=e+a*e^r+b*de^(p/q);
%     ut=(ddzd-(((1+a*r*e^(r-1))*de)+k*s+xite*sign(s))*q/(b*p)*de^(2-p/q))*m;
% end

sys(1)=ut;
sys(2)=e;
sys(3)=de;
sys(4)=s;